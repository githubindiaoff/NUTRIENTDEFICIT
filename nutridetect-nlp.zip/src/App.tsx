import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Activity, 
  FileText, 
  Search, 
  AlertCircle, 
  CheckCircle2, 
  Info, 
  Loader2, 
  Clipboard,
  ChevronRight,
  Stethoscope,
  Microscope,
  Upload,
  X,
  Image as ImageIcon,
  FileCode
} from 'lucide-react';
import { GoogleGenAI, Type } from "@google/genai";
import { cn } from './lib/utils';

interface Deficiency {
  nutrient: string;
  status: 'Deficient' | 'Normal' | 'Borderline' | 'Not Mentioned';
  evidence: string;
  recommendation?: string;
}

interface AnalysisResult {
  deficiencies: Deficiency[];
  summary: string;
  confidence: number;
}

interface UploadedFile {
  file: File;
  preview: string;
  base64: string;
  type: string;
}

const SAMPLE_REPORT = `Patient: John Doe
Age: 45
Date: 2024-03-15

Clinical Notes:
Patient reports persistent fatigue and muscle weakness over the past 3 months. 
Laboratory results indicate Serum Ferritin levels at 12 ng/mL (Reference: 30-400 ng/mL). 
Vitamin D (25-hydroxy) was measured at 18 ng/mL, which is below the optimal range of 30-100 ng/mL. 
B12 levels appear normal at 450 pg/mL. 
Calcium levels are slightly low at 8.2 mg/dL.
Patient also mentions occasional numbness in extremities.`;

export default function App() {
  const [reportText, setReportText] = useState('');
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    const newFiles = await Promise.all(
      files.map(async (file) => {
        const base64 = await fileToBase64(file);
        return {
          file,
          preview: file.type.startsWith('image/') ? URL.createObjectURL(file) : '',
          base64: base64.split(',')[1],
          type: file.type
        };
      })
    );

    setUploadedFiles(prev => [...prev, ...newFiles]);
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const removeFile = (index: number) => {
    setUploadedFiles(prev => {
      const newFiles = [...prev];
      if (newFiles[index].preview) {
        URL.revokeObjectURL(newFiles[index].preview);
      }
      newFiles.splice(index, 1);
      return newFiles;
    });
  };

  const handleAnalyze = async () => {
    if (!reportText.trim() && uploadedFiles.length === 0) return;

    setIsAnalyzing(true);
    setError(null);
    setResult(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
      
      const parts: any[] = [];
      
      if (reportText.trim()) {
        parts.push({ text: `Clinical Report Text:\n${reportText}` });
      }

      uploadedFiles.forEach(file => {
        parts.push({
          inlineData: {
            mimeType: file.type,
            data: file.base64
          }
        });
      });

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: {
          parts: [
            { text: "Analyze the following clinical report (which may include text, images of lab results, or documents) and detect nutrient deficiencies, specifically for Iron, Vitamin D, Vitamin B12, and Calcium. Return the results in a structured JSON format." },
            ...parts
          ]
        },
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              deficiencies: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    nutrient: { type: Type.STRING, description: "Name of the nutrient (e.g., Iron, Vitamin D)" },
                    status: { type: Type.STRING, enum: ["Deficient", "Normal", "Borderline", "Not Mentioned"] },
                    evidence: { type: Type.STRING, description: "Quote or evidence from the report/image" },
                    recommendation: { type: Type.STRING, description: "Brief recommendation based on clinical standards" }
                  },
                  required: ["nutrient", "status", "evidence"]
                }
              },
              summary: { type: Type.STRING, description: "Overall summary of the findings" },
              confidence: { type: Type.NUMBER, description: "Confidence score from 0 to 1" }
            },
            required: ["deficiencies", "summary"]
          }
        }
      });

      const data = JSON.parse(response.text || "{}");
      setResult(data);
    } catch (err) {
      console.error("Analysis error:", err);
      setError(err instanceof Error ? err.message : 'An error occurred during analysis');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getStatusColor = (status: Deficiency['status']) => {
    switch (status) {
      case 'Deficient': return 'text-red-500 bg-red-500/10 border-red-500/20';
      case 'Borderline': return 'text-amber-500 bg-amber-500/10 border-amber-500/20';
      case 'Normal': return 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20';
      default: return 'text-slate-400 bg-slate-400/10 border-slate-400/20';
    }
  };

  return (
    <div className="min-h-screen bg-[#E4E3E0] text-[#141414] font-sans selection:bg-[#141414] selection:text-[#E4E3E0]">
      {/* Header */}
      <header className="border-b border-[#141414] px-6 py-4 flex items-center justify-between bg-white/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[#141414] rounded-sm flex items-center justify-center text-[#E4E3E0]">
            <Microscope size={24} />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight uppercase">NutriDetect NLP</h1>
            <p className="text-[10px] uppercase tracking-widest opacity-50 font-mono">Clinical Deficiency Analysis System v1.0</p>
          </div>
        </div>
        <div className="flex items-center gap-6 text-[11px] font-mono uppercase tracking-wider opacity-60">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            System Active
          </div>
          <div>UTC: {new Date().toISOString().split('T')[0]}</div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Input Section */}
        <section className="lg:col-span-5 space-y-6">
          <div className="bg-white border border-[#141414] p-6 shadow-[4px_4px_0px_0px_rgba(20,20,20,1)]">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-serif italic text-lg flex items-center gap-2">
                <FileText size={18} />
                Clinical Report Input
              </h2>
              <button 
                onClick={() => setReportText(SAMPLE_REPORT)}
                className="text-[10px] uppercase font-bold tracking-wider hover:underline cursor-pointer"
              >
                Load Sample Data
              </button>
            </div>
            
            <textarea
              value={reportText}
              onChange={(e) => setReportText(e.target.value)}
              placeholder="Paste unstructured clinical notes or laboratory reports here..."
              className="w-full h-[200px] p-4 font-mono text-sm bg-[#F8F7F4] border border-[#141414]/10 focus:border-[#141414] focus:ring-0 transition-colors resize-none outline-none"
            />

            {/* File Upload Area */}
            <div className="mt-6 space-y-4">
              <label className="block">
                <span className="text-[10px] uppercase font-bold tracking-wider opacity-50 mb-2 block">Attachments (Images/PDFs)</span>
                <div className="relative group">
                  <input
                    type="file"
                    multiple
                    accept="image/*,application/pdf"
                    onChange={handleFileChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  />
                  <div className="border-2 border-dashed border-[#141414]/20 group-hover:border-[#141414] transition-colors p-8 flex flex-col items-center justify-center gap-2 bg-[#F8F7F4]">
                    <Upload size={24} className="opacity-30 group-hover:opacity-100 transition-opacity" />
                    <p className="text-xs font-medium opacity-50">Drag & drop or click to upload</p>
                    <p className="text-[10px] opacity-30 uppercase tracking-widest">Supports JPG, PNG, PDF</p>
                  </div>
                </div>
              </label>

              {/* Uploaded Files Preview */}
              {uploadedFiles.length > 0 && (
                <div className="grid grid-cols-3 gap-2">
                  {uploadedFiles.map((file, idx) => (
                    <div key={idx} className="relative group aspect-square bg-[#F8F7F4] border border-[#141414]/10 overflow-hidden">
                      {file.preview ? (
                        <img src={file.preview} alt="preview" className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center gap-1">
                          <FileCode size={20} className="opacity-30" />
                          <span className="text-[8px] uppercase font-mono truncate w-full text-center px-1">
                            {file.file.name}
                          </span>
                        </div>
                      )}
                      <button
                        onClick={() => removeFile(idx)}
                        className="absolute top-1 right-1 p-1 bg-red-500 text-white rounded-sm opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-600"
                      >
                        <X size={12} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <button
              onClick={handleAnalyze}
              disabled={isAnalyzing || (!reportText.trim() && uploadedFiles.length === 0)}
              className={cn(
                "w-full mt-6 py-4 flex items-center justify-center gap-3 font-bold uppercase tracking-widest transition-all",
                isAnalyzing || (!reportText.trim() && uploadedFiles.length === 0)
                  ? "bg-slate-200 text-slate-400 cursor-not-allowed" 
                  : "bg-[#141414] text-[#E4E3E0] hover:bg-[#2A2A2A] active:scale-[0.98]"
              )}
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="animate-spin" size={20} />
                  Analyzing Report...
                </>
              ) : (
                <>
                  <Search size={20} />
                  Run NLP Analysis
                </>
              )}
            </button>
          </div>

          <div className="bg-[#141414] text-[#E4E3E0] p-6 border border-[#141414]">
            <h3 className="text-[11px] uppercase tracking-[0.2em] opacity-50 mb-3 font-mono">System Capabilities</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex gap-3">
                <ChevronRight size={16} className="shrink-0 opacity-50" />
                <span>Detects deficiencies in Iron, Vit D, B12, and Calcium</span>
              </li>
              <li className="flex gap-3">
                <ChevronRight size={16} className="shrink-0 opacity-50" />
                <span>Extracts evidence directly from unstructured text</span>
              </li>
              <li className="flex gap-3">
                <ChevronRight size={16} className="shrink-0 opacity-50" />
                <span>Provides context-aware clinical recommendations</span>
              </li>
            </ul>
          </div>
        </section>

        {/* Results Section */}
        <section className="lg:col-span-7 space-y-6">
          <AnimatePresence mode="wait">
            {!result && !isAnalyzing && !error && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="h-full flex flex-col items-center justify-center text-center p-12 border-2 border-dashed border-[#141414]/20 rounded-lg"
              >
                <div className="w-16 h-16 bg-[#141414]/5 rounded-full flex items-center justify-center mb-6">
                  <Stethoscope size={32} className="opacity-20" />
                </div>
                <h3 className="font-serif italic text-xl mb-2">Awaiting Analysis</h3>
                <p className="text-sm opacity-50 max-w-xs">
                  Upload or paste a clinical report to begin the automated nutrient deficiency detection process.
                </p>
              </motion.div>
            )}

            {isAnalyzing && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-6"
              >
                {[1, 2, 3].map((i) => (
                  <div key={i} className="bg-white/50 border border-[#141414]/10 p-6 animate-pulse">
                    <div className="h-4 bg-[#141414]/10 w-1/4 mb-4" />
                    <div className="h-3 bg-[#141414]/5 w-full mb-2" />
                    <div className="h-3 bg-[#141414]/5 w-2/3" />
                  </div>
                ))}
              </motion.div>
            )}

            {error && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-red-50 border border-red-500 p-6 flex gap-4 items-start"
              >
                <AlertCircle className="text-red-500 shrink-0" />
                <div>
                  <h3 className="font-bold text-red-900 uppercase text-xs tracking-wider mb-1">Analysis Error</h3>
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              </motion.div>
            )}

            {result && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                {/* Summary Card */}
                <div className="bg-white border border-[#141414] p-6 shadow-[4px_4px_0px_0px_rgba(20,20,20,1)]">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="font-serif italic text-lg">Executive Summary</h2>
                    <div className="px-2 py-1 bg-[#141414] text-[#E4E3E0] text-[9px] font-mono uppercase tracking-widest">
                      Confidence: {(result.confidence * 100).toFixed(0)}%
                    </div>
                  </div>
                  <p className="text-sm leading-relaxed opacity-80 border-l-2 border-[#141414] pl-4 italic">
                    "{result.summary}"
                  </p>
                </div>

                {/* Deficiency Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {result.deficiencies.map((item, idx) => (
                    <motion.div 
                      key={idx}
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: idx * 0.1 }}
                      className="bg-white border border-[#141414] p-5 flex flex-col"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-bold uppercase text-xs tracking-wider">{item.nutrient}</span>
                        <span className={cn(
                          "text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 border",
                          getStatusColor(item.status)
                        )}>
                          {item.status}
                        </span>
                      </div>
                      
                      <div className="flex-grow">
                        <div className="flex gap-2 mb-3">
                          <Info size={14} className="shrink-0 opacity-30 mt-0.5" />
                          <p className="text-[11px] leading-tight opacity-60 font-mono italic">
                            "{item.evidence}"
                          </p>
                        </div>
                        
                        {item.recommendation && (
                          <div className="mt-4 pt-4 border-t border-[#141414]/5">
                            <h4 className="text-[10px] font-bold uppercase tracking-wider mb-2 flex items-center gap-2">
                              <CheckCircle2 size={12} className="text-emerald-500" />
                              Clinical Recommendation
                            </h4>
                            <p className="text-xs opacity-80 leading-snug">
                              {item.recommendation}
                            </p>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>

                {/* Footer Info */}
                <div className="text-[10px] font-mono uppercase tracking-widest opacity-40 text-center pt-4">
                  AI-Generated Analysis • For Professional Use Only • Verify with Clinical Data
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      </main>
    </div>
  );
}
